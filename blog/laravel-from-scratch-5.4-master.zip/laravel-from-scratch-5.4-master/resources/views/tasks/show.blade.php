<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>

<body>

<h1>{{$task->body}}</h1>

</body>
</html>
