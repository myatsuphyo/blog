<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>

<body>

<h1>{{$tasks->body}}</h1>

</body>
</html>
