<?php

namespace App;

class Redis
{
    
}